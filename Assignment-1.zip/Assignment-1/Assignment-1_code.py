#!/usr/bin/env python
# coding: utf-8

# In[1]:


print('welcome to the world of python, this is my first notebook')


# In[4]:


#First assignment
'''
Write a program which will find all such numbers which are divisible by 7 but are not a multiple
of 5, between 2000 and 3200 (both included). The numbers obtained should be printed in a
comma-separated sequence on a single line.
'''
nl=[]
for x in range(2000,3200):
    if (x%7==0) and (x%5!=0):
        nl.append(str(x))
print (','.join(nl))


# In[6]:


'''Write a Python program to accept the user's first and last name and then getting them printed in
the the reverse order with a space between first name and last name.'''
first_name=input("Enter user's first name ")
last_name=input("Enter user's last name ")
print('last name is',last_name,'first name is',first_name)


# In[11]:


'''Write a Python program to find the volume of a sphere with diameter 12 cm.
Formula: V=4/3 * π * r
3'''
radius=input('Enter the radius of the sphere ')
r=float(radius)
pie=3.14
area=(4/3)*pie*(r**3)
print('The area of sphere is',area)


# In[16]:


'''Write a program which accepts a sequence of comma-separated numbers from console and
generate a list.'''
values = input("Input comma seperated numbers : ")
list = values.split(",")
print(list)


# 
# 

# In[17]:


'''Write a Python program to reverse a word after accepting the input from the user.'''
value=input('Enter a string to be reversed')
print('The reversed string is ',value[::-1])


# In[18]:


'''Create the below pattern using nested for loop in Python'''
rows = int(input("Enter a value "))
for i in range(0, rows):
    for j in range(0, i + 1):
        print("*", end=' ')
    print("\r")

for i in range(rows, 0, -1):
    for j in range(0, i - 1):
        print("*", end=' ')
    print("\r")


# In[24]:


'''Write a Python Program to print the given string in the format specified in the sample output.
WE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India into a
SOVEREIGN, SOCIALIST, SECULAR, DEMOCRATIC REPUBLIC and to secure to all
its citizens'''

value=input('Enter the sentence')
sentences=value.split(',')
for sentence in sentences:
    print(sentence)


# In[ ]:




